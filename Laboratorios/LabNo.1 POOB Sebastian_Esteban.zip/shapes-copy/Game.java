import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 * Write a description of class Juego here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Game
{
    // instance variables - replace the example below with your own
    private ArrayList<Tower> towers;
    private Rectangle disk;
    

    
    public Game()
    {
        
        towers=new ArrayList<>();
        constructGame();
        
    }
    private void constructGame(){
        Tower towerOne;
        Tower towerTwo;
        Tower towerThree;
        
        towerOne=new Tower(20);
        towerTwo=new Tower(0);
        towerThree=new Tower(0);
        
        towerOne.makeVisible();
        towers.add(towerOne);
        
        towerTwo.moveTo(550,10);
        towerTwo.makeVisible();
        towers.add(towerTwo);
        
        
        towerThree.moveTo(1000,10);
        towerThree.makeVisible();
        towers.add(towerThree);
    }

    public void moveDiskStick(int firstTowerPosition, int secondTowerPosition){  
        Tower firstTower= towers.get(firstTowerPosition-1);
        Tower secondTower= towers.get(secondTowerPosition-1);
        int topNumDiskFirstTower=firstTower.getTopNumDisk();
        int topNumDiskSecondTower=secondTower.getTopNumDisk();
        
        if (topNumDiskFirstTower<topNumDiskSecondTower){
            secondTower.push(topNumDiskFirstTower);
            firstTower.pop();
        }else{
            JOptionPane.showMessageDialog(null, "You are trying to put a disk bigger over a disk smaller ", "Empty Array",JOptionPane.WARNING_MESSAGE);
        }

        
        
        
        
        
        
    }
    
}
