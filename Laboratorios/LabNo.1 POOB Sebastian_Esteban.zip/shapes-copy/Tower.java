import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;
 
/**
 * Write a description of class tower here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tower
{
    // instance variables - replace the example below with your own
    private Rectangle stick;
    private int disks;
    private ArrayList<Rectangle> diskList;
    private String[] colors={"red", "blue", "yellow", "green", "magenta", "gray", "orange", "pink", "cyan", "purple", "violet", "indigo", "lime", "teal", "olive", "navy", "maroon"};
    private int xPosition=130;
    private int yPosition=10;
    private boolean isVisible;
    private final int HEIGTH=20;
    private final int STICK_WIDTH=10;
    public Tower(int disks)
    {
        if (disks <= 20 && disks>=0) {
            this.disks = disks;
            this.diskList = new ArrayList<>();
            constructStick();
            constructDisks();
        } else {
            JOptionPane.showMessageDialog(null, "The number of disks must be less than 20.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void constructDisks(){
        int width=220;

        for(int i=0; i<disks; i++){
            Rectangle disk = new Rectangle();
            disk.changeSize(HEIGTH,width);
            diskList.add(0,disk);
            width-=10;
        }
        beginingPosition();
        changeColors();

    }
    private void constructStick(){
        stick=new Rectangle();
        stick.changeSize((21)*HEIGTH,STICK_WIDTH);
        stick.changeColor("Black");
        stick.moveHorizontal(5);
    }
    
    public void makeVisible(){
        this.isVisible=true;
        stick.makeVisible();
        for (int i=0; i<diskList.size(); i++){
            Rectangle disk = diskList.get(i);
            disk.makeVisible();
        }
    }
    
    public void makeInvisible(){
        this.isVisible=false;
        stick.makeInvisible();
        for (int i=0; i<diskList.size(); i++){
            Rectangle disk = diskList.get(i);
            disk.makeInvisible();
        }
    }
    public void moveTo(int xPosition, int yPosition){
        int x=xPosition-this.xPosition;
        int y=yPosition-this.yPosition;
        this.xPosition=xPosition;
        this.yPosition=yPosition;
        stick.moveVertical(y);
        stick.moveHorizontal(x);
        for(int i=disks-1; i>-1; i--){
            Rectangle disk = diskList.get(i);
            disk.moveVertical(y);
            disk.moveHorizontal(x);
            
        }

    }
    public void beginingPosition(){
        int x=-100;
        int y=400;
        for(int i=disks-1; i>-1; i--){
            Rectangle disk = diskList.get(i);
            disk.moveVertical(y);
            disk.moveHorizontal(x);
            y-=20;
            x+=5;
        }   
    }
    
    public void moveHorizontalTStick(int Distance){
        stick.moveHorizontal(Distance);
    }
    public void changeColors(){
        for (int i=0; i<diskList.size(); i++){
            Rectangle disk = diskList.get(i);
            disk.changeColor(randomColor());
        }
    }
    
    public String randomColor(){
        Random random= new Random();
        int colorPosition=random.nextInt(colors.length);
        return colors[colorPosition];
    }
    public boolean pop(){
        if (diskList.size()>0){
            Rectangle disk= diskList.get(0);
            disk.makeInvisible();
            diskList.remove(0);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "There is anything to pop ", "Empty Array",JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
    }
    
    public void push(int newNumDisk){
        int newDiskWidth=220-(20-newNumDisk)*10;
        int oldNumDisk=getTopNumDisk();
        int xPositionOldDisk;
        int yPositionOldDisk;
        
        if (oldNumDisk<=newNumDisk){
            JOptionPane.showMessageDialog(null, "The disk that you are trying to push is bigger than the smallest disk in the tower ", "Size Error",JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (diskList.size()>0){
            Rectangle disk= diskList.get(0);
            xPositionOldDisk=disk.getxPosition();
            yPositionOldDisk=disk.getyPosition();
            
        }
        else{
            int stickHeigth= (21)*HEIGTH;
            int xPositionStick= stick.getxPosition();
            int yPositionStick= stick.getyPosition();
            xPositionOldDisk=xPositionStick-120+STICK_WIDTH;
            yPositionOldDisk=yPositionStick+stickHeigth;
        }
        if (diskList.size()<=20 &&  newNumDisk>0 && newNumDisk<21 ){ 
            
            Rectangle pushDisk = new Rectangle();
            pushDisk.changeSize(HEIGTH,newDiskWidth);
            pushDisk.moveHorizontal(xPositionOldDisk-130+5*(oldNumDisk-newNumDisk));
            pushDisk.moveVertical(yPositionOldDisk-30);
            pushDisk.changeColor(randomColor());
            pushDisk.makeVisible();
            diskList.add(0,pushDisk);
            
            
            
            
        } else {
            JOptionPane.showMessageDialog(null, "There is anything to push or you are trying to push more than 20 disks ", "Empty Array",JOptionPane.WARNING_MESSAGE);
        }
    }
    public int getTopNumDisk(){
        if (diskList.size()==0){
            return 21;
        }
        Rectangle disk=diskList.get(0);
        int diskWidth= disk.getWidth();
        return (diskWidth/10)-2;
    }
}
